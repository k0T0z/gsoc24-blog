#include "mainwindow.h"
#include "glwidget.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    // Create OpenGL widget and set as central widget
    GLWidget *glWidget = new GLWidget(this);
    setCentralWidget(glWidget);

    setMinimumSize(800, 600);
}

MainWindow::~MainWindow() {}
