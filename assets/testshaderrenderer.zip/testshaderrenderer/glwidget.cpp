#include "glwidget.h"

GLWidget::GLWidget(QWidget *parent)
    : QOpenGLWidget(parent), shaderProgram(nullptr), VAO(0), VBO(0), EBO(0)
{
    // Start the timer to measure elapsed time since the widget initialization
    timer.start();
}

GLWidget::~GLWidget()
{
    makeCurrent();
    // glDeleteVertexArrays(1, &VAO);
    glDeleteBuffers(1, &VBO);
    glDeleteBuffers(1, &EBO);
    delete shaderProgram;
    doneCurrent();
}

void GLWidget::initializeGL()
{
    initializeOpenGLFunctions();

    // Set up shaders and buffers
    initShaders();
    initBuffers();
}

void GLWidget::resizeGL(int w, int h)
{
    glViewport(0, 0, w, h);
}

void GLWidget::paintGL()
{
    // Get elapsed time in seconds
    float timeValue = timer.elapsed() / 1000.0f;

    glClear(GL_COLOR_BUFFER_BIT);

    // Use the shader program and pass the time value
    shaderProgram->bind();
    shaderProgram->setUniformValue("uTime", timeValue);

    // glBindVertexArray(VAO);
    glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, nullptr);
    // glBindVertexArray(0);

    shaderProgram->release();

    // Request the next frame update to be called as soon as possible
    update();  // Triggers the paintGL() to be called again
}

void GLWidget::initShaders()
{
    // Vertex shader source code
    const char *vertexShaderSource = R"(
        #version 330 core
        layout(location = 0) in vec3 aPos;
        layout(location = 1) in vec2 aTexCoord;

        out vec2 TexCoord;

        void main()
        {
            gl_Position = vec4(aPos, 1.0);
            TexCoord = aTexCoord;
        }
    )";

    // Fragment shader source code
    const char *fragmentShaderSource = R"(
        #version 330 core
        out vec4 FragColor;
        in vec2 TexCoord;

        uniform float uTime;

        float noise_random_value(vec2 uv) {
            return fract(sin(dot(uv, vec2(12.9898, 78.233)))*43758.5453);
        }

        float noise_interpolate(float a, float b, float t) {
            return (1.0-t)*a + (t*b);
        }

        float value_noise(vec2 uv) {
            vec2 i = floor(uv);
            vec2 f = fract(uv);
            f = f * f * (3.0 - 2.0 * f);

            uv = abs(fract(uv) - 0.5);
            vec2 c0 = i + vec2(0.0, 0.0);
            vec2 c1 = i + vec2(1.0, 0.0);
            vec2 c2 = i + vec2(0.0, 1.0);
            vec2 c3 = i + vec2(1.0, 1.0);
            float r0 = noise_random_value(c0);
            float r1 = noise_random_value(c1);
            float r2 = noise_random_value(c2);
            float r3 = noise_random_value(c3);

            float bottomOfGrid = noise_interpolate(r0, r1, f.x);
            float topOfGrid = noise_interpolate(r2, r3, f.x);
            float t = noise_interpolate(bottomOfGrid, topOfGrid, f.y);
            return t;
        }

        void generate_value_noise_float(vec2 uv, float scale, out float out_buffer) {
            float t = 0.0;

            float freq = pow(2.0, float(0));
            float amp = pow(0.5, float(3-0));
            t += value_noise(vec2(uv.x*scale/freq, uv.y*scale/freq))*amp;

            freq = pow(2.0, float(1));
            amp = pow(0.5, float(3-1));
            t += value_noise(vec2(uv.x*scale/freq, uv.y*scale/freq))*amp;

            freq = pow(2.0, float(2));
            amp = pow(0.5, float(3-2));
            t += value_noise(vec2(uv.x*scale/freq, uv.y*scale/freq))*amp;

            out_buffer = t;
        }


        void main()
        {
            vec2 uv = TexCoord;

            // Value Noise
            float out_buffer = 0.0;
            generate_value_noise_float(uv, 100.000000, out_buffer);
            vec4 var_from_n5_p0 = vec4(out_buffer, out_buffer, out_buffer, 1.0);

            // Time-based animation
            float time_factor = sin(uTime);
            float final_value = var_from_n5_p0.x / time_factor;

            // Output the result to RGB
            FragColor = vec4(vec3(final_value), 1.0);
        }
    )";

    // Compile and link shaders
    shaderProgram = new QOpenGLShaderProgram();
    shaderProgram->addShaderFromSourceCode(QOpenGLShader::Vertex, vertexShaderSource);
    shaderProgram->addShaderFromSourceCode(QOpenGLShader::Fragment, fragmentShaderSource);
    shaderProgram->link();
}

void GLWidget::initBuffers()
{
    // Vertices for a full-screen quad (positions and texture coordinates)
    float vertices[] = {
        // positions    // texCoords
        -1.0f,  1.0f,   0.0f, 1.0f,
        -1.0f, -1.0f,   0.0f, 0.0f,
        1.0f, -1.0f,   1.0f, 0.0f,
        1.0f,  1.0f,   1.0f, 1.0f
    };

    unsigned int indices[] = { 0, 1, 2, 0, 2, 3 };

    // glGenVertexArrays(1, &VAO);
    glGenBuffers(1, &VBO);
    glGenBuffers(1, &EBO);

    // glBindVertexArray(VAO);

    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 4 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 4 * sizeof(float), (void*)(2 * sizeof(float)));
    glEnableVertexAttribArray(1);

    // glBindVertexArray(0);
}
