#include <QCoreApplication>
#include <QProcess>
#include <QObject>
#include <iostream>

class QProcessTest : public QObject {
    Q_OBJECT

public:
    explicit QProcessTest(QObject *parent = nullptr) : QObject(parent) {
        QString program = "/home/k0t0z/Desktop/gsoc24/RadialGM/Submodules/enigma-dev/emake-debug";

        QStringList arguments;
        arguments << "--server"
                  << "-e"
                  << "Paths"
                  << "-r"
                  << "--quiet"
                  << "--enigma-root"
                  << "/home/k0t0z/Desktop/gsoc24/RadialGM/Submodules/enigma-dev";

        process = new QProcess(parent);

        connect(process, &QProcess::errorOccurred, this, &QProcessTest::onErrorOccurred);
        connect(process, QOverload<int, QProcess::ExitStatus>::of(&QProcess::finished), this, &QProcessTest::onFinished);
        connect(process, &QProcess::readyReadStandardError, this, &QProcessTest::onReadyReadStandardError);
        connect(process, &QProcess::readyReadStandardOutput, this, &QProcessTest::onReadyReadStandardOutput);
        connect(process, &QProcess::started, this, &QProcessTest::onProcessStarted);
        connect(process, &QProcess::stateChanged, this, &QProcessTest::onStateChanged);

        std::cout << "Starting..." << std::endl;
        process->setWorkingDirectory("/home/k0t0z/Desktop/gsoc24/RadialGM/Submodules/enigma-dev");
        process->start(program, arguments);

        if (!process->waitForStarted(-1))
            std::cout << "Oh shit!" << std::endl;

    }

    ~QProcessTest() {
        if (!process->waitForFinished(-1))
            std::cout << "Oh yaaah" << std::endl;
    }

private slots:
    void onErrorOccurred(QProcess::ProcessError error) {
        switch (error) {
            case QProcess::FailedToStart:
                std::cout << "Error: The process failed to start. Either the invoked program is missing, or you may have insufficient permissions to invoke the program." << std::endl;
                break;
            case QProcess::Crashed:
                std::cout << "Error: The process crashed some time after starting successfully." << std::endl;
                break;
            case QProcess::Timedout:
                std::cout << "Error: The last waitFor...() function timed out. The state of QProcess is unchanged, and you can try calling waitFor...() again." << std::endl;
                break;
            case QProcess::WriteError:
                std::cout << "Error: An error occurred when attempting to write to the process. For example, the process may not be running, or it may have closed its input channel." << std::endl;
                break;
            case QProcess::ReadError:
                std::cout << "Error: An error occurred when attempting to read from the process. For example, the process may not be running." << std::endl;
                break;
            case QProcess::UnknownError:
                std::cout << "Error: An unknown error occurred. This is the default return value of error()." << std::endl;
                break;
            default:
                std::cout << "Error: Unrecognized error code." << std::endl;
                break;
        }
    }

    void onFinished(int exitCode, QProcess::ExitStatus exitStatus) {
        switch (exitStatus) {
            case QProcess::NormalExit:
                std::cout << "Exit Status: The process exited normally." << std::endl;
                break;
            case QProcess::CrashExit:
                std::cout << "Exit Status: The process crashed." << std::endl;
                break;
            default:
                std::cout << "Exit Status: Unrecognized exit status code." << std::endl;
                break;
        }
        std::cout << "Exit Code: " << exitCode << std::endl;
    }

    void onReadyReadStandardError() {
        std::cout << "Standard Error: " << process->readAllStandardError().constData() << std::endl;
    }

    void onReadyReadStandardOutput() {
        std::cout << "Standard Output: " << process->readAllStandardOutput().constData() << std::endl;
    }

    void onProcessStarted() {
        // Handle the process started event
        std::cout << "Process started successfully!" << std::endl;
    }

    void onStateChanged(QProcess::ProcessState state) {
        switch (state) {
            case QProcess::NotRunning:
                std::cout << "State: The process is not running." << std::endl;
                break;
            case QProcess::Starting:
                std::cout << "State: The process is starting, but the program has not yet been invoked." << std::endl;
                break;
            case QProcess::Running:
                std::cout << "State: The process is running and is ready for reading and writing." << std::endl;
                break;
            default:
                std::cout << "State: Unrecognized state code." << std::endl;
                break;
        }
    }

private:
    QProcess* process;
};

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    // Set up code that uses the Qt event loop here.
    // Call a.quit() or a.exit() to quit the application.
    // A not very useful example would be including
    // #include <QTimer>
    // near the top of the file and calling
    // QTimer::singleShot(5000, &a, &QCoreApplication::quit);
    // which quits the application after 5 seconds.

    // If you do not need a running Qt event loop, remove the call
    // to a.exec() or use the Non-Qt Plain C++ Application template.

    QObject *parent = new QObject();

    QProcessTest *test = new QProcessTest(parent);

    return a.exec();
}

#include "main.moc"

