#include "mainwindow.h"

#include <QAction>
#include <QScreen>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QRadioButton>

using QtNodes::NodeRole;

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), graph(nullptr), scene(nullptr), layout(nullptr), view(nullptr) {
    //   this->setWindowIcon(QIcon(":/resources/visual_shader.png"));

    graph = new VisualShaderGraph();

    // Initialize and connect two nodes.
    {
        NodeId id1 = graph->addNode();
        graph->setNodeData(id1, NodeRole::Position, QPointF(0, 0));

        NodeId id2 = graph->addNode();
        graph->setNodeData(id2, NodeRole::Position, QPointF(300, 300));

        graph->addConnection(ConnectionId{id1, 0, id2, 0});
    }

    scene = new BasicGraphicsScene(*graph);

    scene->setOrientation(Qt::Horizontal);

    QWidget *centralWidget = new QWidget(this);  // Create a central widget for QMainWindow
    layout = new QHBoxLayout(centralWidget);

    view = new GraphicsView(scene);

    layout->addWidget(view);

    QGroupBox *groupBox = new QGroupBox("Orientation");

    QRadioButton *radio1 = new QRadioButton("Vertical");
    QRadioButton *radio2 = new QRadioButton("Horizontal");

    QVBoxLayout *vbl = new QVBoxLayout;
    vbl->addWidget(radio1);
    vbl->addWidget(radio2);
    vbl->addStretch();
    groupBox->setLayout(vbl);

    QObject::connect(radio1, &QRadioButton::clicked, [this]() {
        scene->setOrientation(Qt::Vertical);
    });

    QObject::connect(radio2, &QRadioButton::clicked, [this]() {
        scene->setOrientation(Qt::Horizontal);
    });

    radio1->setChecked(true);

    layout->addWidget(groupBox);

    // Setup context menu for creating new nodes.
    view->setContextMenuPolicy(Qt::ActionsContextMenu);
    QAction createNodeAction(QStringLiteral("Create Node"), view);
    QObject::connect(&createNodeAction, &QAction::triggered, [&]() {
        // Mouse position in scene coordinates.
        QPointF posView = view->mapToScene(view->mapFromGlobal(QCursor::pos()));

        NodeId const newId = graph->addNode();
        graph->setNodeData(newId, NodeRole::Position, posView);
    });
    view->insertAction(view->actions().front(), &createNodeAction);

    // view->setWindowTitle("Simple Node Graph");
    // view->resize(800, 600);

    // Center window.
    // view->move(QApplication::primaryScreen()->availableGeometry().center() - view->rect().center());
    // view->showNormal();

    // Set the main window's central widget and other properties
    this->setCentralWidget(centralWidget);  // Set the central widget
    // this->setWindowTitle("Simple Node Graph");
    // this->resize(800, 600);  // Set the size of the main window
}

MainWindow::~MainWindow() {}
